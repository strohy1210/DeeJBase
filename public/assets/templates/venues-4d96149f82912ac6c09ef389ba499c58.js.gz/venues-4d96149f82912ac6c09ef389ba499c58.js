Ember.TEMPLATES["venues"] = Ember.Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
  data.buffer.push("All the Venues\n");
  },"useData":true});
